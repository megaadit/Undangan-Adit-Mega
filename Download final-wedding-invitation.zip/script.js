document.getElementById('openBtn').addEventListener('click', () => {
  document.getElementById('splash').classList.add('hide');
  document.getElementById('content').classList.remove('hide');

  const params = new URLSearchParams(window.location.search);
  const guest = params.get('to') || 'Bapak/Ibu/Saudara/i';
  document.getElementById('guestName').textContent = decodeURIComponent(guest);
});